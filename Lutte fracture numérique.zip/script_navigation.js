// ==================== script_navigation.js ====================
// ==================== VARIABLES GLOBALES ====================
let voiceEnabled = false;

// ==================== NAVIGATION ====================
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    const targetPage = document.getElementById(`page-${pageId}`);
    if (targetPage) {
        targetPage.classList.add('active');
        
        // CORRECTION DE L'ANCRAGE : Ne plus utiliser de valeur fixe.
        if (pageId === 'landing') {
            window.scrollTo({ top: 0, behavior: 'smooth' });}
        else if (pageId === 'summary') {
            window.scrollTo({ top: 950, behavior: 'smooth' });
        } 
        else {
            // Cible la carte (conteneur du titre) de la page activée.
            const card = targetPage.querySelector('.card');
            if (card) {
                // Ancre la vue sur le haut de la carte (début du bloc)
                card.scrollIntoView({ behavior: 'smooth', block: 'start' });
            
            } else {
                 // Fallback si pas de carte (pour les autres pages)
                window.scrollTo({ top: 975, behavior: 'smooth' });
            }
        }
    }
}


function goToLanding() { 
    showPage('landing'); 
}

function goToSummary() { 
    showPage('summary'); 
}

function openCourse() { 
    courseIndex = 0;
    renderCourse();
    showPage('course'); 
}

function openGame() {
    loadGameState();
    renderGameLevels();
    showPage('game');
}

function openDemarches() {
    renderDemarchesCategories();
    showPage('demarches');
}


// ==================== ACCESSIBILITÉ ====================
function changeFontSize(size) {
    document.body.classList.remove('large-text', 'xl-text');
    if (size === 'large') document.body.classList.add('large-text');
    if (size === 'xl') document.body.classList.add('xl-text');
    localStorage.setItem('fontSize', size);
}

function toggleContrast() {
    document.body.classList.toggle('high-contrast');
    localStorage.setItem('highContrast', document.body.classList.contains('high-contrast'));
}

function toggleVoice() {
    voiceEnabled = !voiceEnabled;
    localStorage.setItem('voiceEnabled', voiceEnabled);
    speakText(voiceEnabled ? 'Voix activée' : 'Voix désactivée');
}

function speakText(text) {
    if (!voiceEnabled || !('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'fr-FR';
    utterance.rate = 0.9;
    window.speechSynthesis.speak(utterance);
}

function showHelp() {
    alert('Besoin d\'aide ?\n\n• France Services : 3939\n• Assistance numérique : 0 809 401 401\n• CNIL : 01 53 73 22 22');
}

function restorePreferences() {
    const fontSize = localStorage.getItem('fontSize');
    const highContrast = localStorage.getItem('highContrast') === 'true';
    voiceEnabled = localStorage.getItem('voiceEnabled') === 'true';
    if (fontSize) changeFontSize(fontSize);
    if (highContrast) document.body.classList.add('high-contrast');
}

// ==================== INITIALISATION ====================
window.addEventListener('DOMContentLoaded', () => {
    restorePreferences();
    renderCourse();
    
    // Restaurer la progression du cours
    const savedCourseIndex = localStorage.getItem('courseIndex');
    if (savedCourseIndex) {
        courseIndex = parseInt(savedCourseIndex);
    }
});

// Sauvegarder automatiquement
window.addEventListener('beforeunload', () => {
    localStorage.setItem('courseIndex', courseIndex);
});
